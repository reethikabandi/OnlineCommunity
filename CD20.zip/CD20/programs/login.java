package logic;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Window;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class login {

	JFrame frame;
	private JTextField tfcuname;
	private JPasswordField tfcpwd;
	String cuname,cpwd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login window = new login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 240, 240));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("         LOGIN");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(135, 10, 113, 29);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("USERNAME   :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(100, 65, 111, 23);
		frame.getContentPane().add(lblNewLabel_1);
		
		tfcuname = new JTextField();
		tfcuname.setBounds(198, 68, 96, 19);
		frame.getContentPane().add(tfcuname);
		tfcuname.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("PASSWORD  :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(100, 98, 101, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		tfcpwd = new JPasswordField();
		tfcpwd.setBounds(198, 96, 96, 19);
		frame.getContentPane().add(tfcpwd);
		
		JButton btnlogin = new JButton("LOGIN");
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sru", "root", "");
					Statement stmt = con.createStatement();
					cuname = tfcuname.getText();
					cpwd = String.valueOf(tfcpwd.getPassword());
					String qry = "select * from insta where cuname ='"+cuname+"'";
					ResultSet rs = stmt.executeQuery(qry);
					String dbUname=null, dbName=null, dbPwd=null;
					if(rs.next()) {
						dbUname = rs.getString("cuname");
						dbName = rs.getString("cname");
						dbPwd = rs.getString("cpwd");
					}
					if(cuname.equalsIgnoreCase(dbUname) && cpwd.equals(dbPwd)) {
					//	JOptionPane.showMessageDialog(btnlogin, "Login Sucessfull");
						PROFILE pro = new PROFILE();
						pro.frame.setVisible(true);
						frame.dispose();
					}
					else {
						JOptionPane.showMessageDialog(btnlogin, "Login failed");
					}
				}
				catch(Exception ex) {ex.printStackTrace(); }
				
			}
		});
		btnlogin.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnlogin.setBounds(114, 136, 85, 36);
		frame.getContentPane().add(btnlogin);
		
		JLabel lblNewLabel_3 = new JLabel("NEW USER ? CLICK HERE");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setBounds(73, 198, 211, 36);
		frame.getContentPane().add(lblNewLabel_3);
		
		JButton btnNewButton_1 = new JButton("CLEAR");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tfcuname.setText(""); // Clear the username text field
		        tfcpwd.setText(""); // Clear the password field
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(209, 136, 85, 36);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("SIGN UP");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SIGNUP sp = new SIGNUP();
				sp.frame.setVisible(true);
				frame.dispose();
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.setBounds(268, 198, 121, 36);
		frame.getContentPane().add(btnNewButton_2);
	}
}
