package logic;

import java.awt.EventQueue;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.awt.event.ActionEvent;

public class SIGNUP {

	JFrame frame;
	private JTextField tfcname;
	private JTextField tfcmail;
	private JTextField tfcnumber;
	private JTextField tfcuname;
	private JPasswordField tfcpwd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SIGNUP window = new SIGNUP();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SIGNUP() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(193, 191, 191));
		frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 15));
		frame.setBounds(100, 100, 453, 320);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("SIGN UP");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(180, 10, 74, 32);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("NAME             :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(120, 68, 102, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("EMAIL            :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(120, 91, 98, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("NUMBER         :");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3.setBounds(120, 116, 98, 13);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("USERNAME     :");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_4.setBounds(120, 140, 102, 13);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("PASSWORD    :");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_5.setBounds(120, 163, 102, 13);
		frame.getContentPane().add(lblNewLabel_5);
		
		tfcname = new JTextField();
		tfcname.setBounds(228, 66, 96, 19);
		frame.getContentPane().add(tfcname);
		tfcname.setColumns(10);
		
		tfcmail = new JTextField();
		tfcmail.setBounds(228, 89, 96, 19);
		frame.getContentPane().add(tfcmail);
		tfcmail.setColumns(10);
		
		tfcnumber = new JTextField();
		tfcnumber.setBounds(228, 114, 96, 19);
		frame.getContentPane().add(tfcnumber);
		tfcnumber.setColumns(10);
		
		tfcuname = new JTextField();
		tfcuname.setBounds(228, 138, 96, 19);
		frame.getContentPane().add(tfcuname);
		tfcuname.setColumns(10);
		
		JButton btnNewButton = new JButton("SIGN UP");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sru", "root", "");
                    Statement stmt = con.createStatement();
                    String cname = tfcname.getText();
                    String cmail = tfcmail.getText();
                    String cnumber = tfcnumber.getText();
                    String cuname = tfcuname.getText();
                    char[] password = tfcpwd.getPassword(); // Get password as char array
                    String cpwd = new String(password); // Convert char array to string
                    String sql = "insert into insta values('" + cname + "', '" + cmail + "', '" + cnumber + "', '" + cuname + "','" + cpwd + "')";
                    stmt.executeUpdate(sql);
                    JOptionPane.showMessageDialog(frame, "Registration Completed Successfully");
					login log = new login();
					log.frame.setVisible(true);
					frame.dispose();
				}
				catch(Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		btnNewButton.setBackground(new Color(192, 192, 192));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(120, 218, 102, 34);
		frame.getContentPane().add(btnNewButton);
		
		tfcpwd = new JPasswordField();
		tfcpwd.setBounds(228, 161, 96, 19);
		frame.getContentPane().add(tfcpwd);
		
		JButton btnNewButton_1 = new JButton("CLEAR");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tfcname.setText(""); // Clear the name text field
		        tfcmail.setText(""); // Clear the email text field
		        tfcnumber.setText(""); // Clear the number text field
		        tfcuname.setText(""); // Clear the username text field
		        tfcpwd.setText(""); // Clear the password field
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(245, 219, 102, 32);
		frame.getContentPane().add(btnNewButton_1);
	}
}
